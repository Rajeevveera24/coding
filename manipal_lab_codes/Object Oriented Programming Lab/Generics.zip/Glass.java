package com.java9s.tutorials.java.generics;

public class Glass<T> {
	public T liquid;
}
