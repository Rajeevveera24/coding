package com.java9s.tutorials.java.generics;

public class Red {

}
