package com.java9s.tutorials.java.generics;

public class Bartender {
	public <J,W> void mix(J juice, W water){
		System.out.println("Mix");
	}
}
